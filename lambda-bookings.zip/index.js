/* eslint-disable @typescript-eslint/no-require-imports */
const mysql = require("mysql2/promise");
const jwt = require("jsonwebtoken");

const JWT_SECRET = "stocknbook-secret-key";

const dbConfig = {
    host: "stocknbook-db.clyuqe48evd0.ap-southeast-1.rds.amazonaws.com",
    user: "admin",
    password: "2qJivedWDxCQS6TLjjEl",
    database: "stocknbook",
    ssl: { rejectUnauthorized: false },
};

exports.handler = async (event) => {
    const headers = {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Content-Type": "application/json",
    };

    if (event.httpMethod === "OPTIONS") {
        return {
            statusCode: 200,
            headers,
            body: "",
        };
    }

    let body = {};
    try {
        body = JSON.parse(event.body || "{}");
    } catch (error) {
        body = {};
    }

    const action = body.action;
    const connection = await mysql.createConnection(dbConfig);

    try {
        if (action === "create_booking") {
            const {
                storeId,
                bookingReference,
                bookingType,
                name,
                facebookName,
                phone,
                email,
                date,
                eventTime,
                eventType,
                package: packageName,
                customOrder,
                theme,
                venue,
                notes,
                status,
            } = body;

            if (!storeId || !bookingType || !name || !phone || !date) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing required booking fields" }),
                };
            }

            const [result] = await connection.execute(
                `INSERT INTO bookings
                 (store_id, booking_reference, booking_type, name, facebook_name,
                  phone, email, event_date, event_time, event_type, package_name,
                  custom_order, theme, venue, notes, status)
                 VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    Number(storeId),
                    bookingReference || null,
                    bookingType,
                    name,
                    facebookName || null,
                    phone,
                    email || null,
                    date,
                    eventTime || null,
                    eventType || "Based on selected package",
                    packageName || "",
                    customOrder || "",
                    theme || null,
                    venue || null,
                    notes || "",
                    status || "Pending Review",
                ]
            );

            return {
                statusCode: 201,
                headers,
                body: JSON.stringify({ success: true, id: result.insertId }),
            };
        }

        // PUBLIC: get booking by reference
        if (action === "get_booking_by_reference") {
            const { bookingReference } = body;

            if (!bookingReference) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing bookingReference" }),
                };
            }

            const [rows] = await connection.execute(
                `SELECT
                     id,
                     booking_reference AS bookingReference,
                     booking_type AS bookingType,
                     name,
                     facebook_name AS facebookName,
                     phone,
                     email,
                     event_date AS date,
            event_time AS eventTime,
            event_type AS eventType,
            package_name AS package,
            custom_order AS customOrder,
            theme,
            venue,
            notes,
            status,
            created_at AS createdAt
                 FROM bookings
                 WHERE booking_reference = ?
                     LIMIT 1`,
                [bookingReference]
            );

            if (!rows.length) {
                return {
                    statusCode: 404,
                    headers,
                    body: JSON.stringify({ error: "Booking not found" }),
                };
            }

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ booking: rows[0] }),
            };
        }

        // PUBLIC: get bookings by phone
        if (action === "get_bookings_by_phone") {
            const { phone, storeId } = body;

            if (!phone || !storeId) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing phone or storeId" }),
                };
            }

            const [rows] = await connection.execute(
                `SELECT
                     id,
                     booking_reference AS bookingReference,
                     booking_type AS bookingType,
                     name,
                     phone,
                     event_date AS date,
            event_time AS eventTime,
            event_type AS eventType,
            package_name AS package,
            custom_order AS customOrder,
            theme,
            venue,
            notes,
            status,
            created_at AS createdAt
                 FROM bookings
                 WHERE phone = ? AND store_id = ?
                 ORDER BY created_at DESC`,
                [phone, Number(storeId)]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ bookings: rows }),
            };
        }

        if (action === "get_public_bookings") {
            const { storeId } = body;

            if (!storeId) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing storeId" }),
                };
            }

            const [rows] = await connection.execute(
                `SELECT
       id,
       name,
       event_date AS date,
       status
     FROM bookings
     WHERE store_id = ?
     ORDER BY created_at DESC`,
                [storeId]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ bookings: rows }),
            };
        }

        // PROTECTED actions
        const authHeader = event.headers?.Authorization || event.headers?.authorization;

        if (!authHeader) {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ error: "No token" }),
            };
        }

        let store_id;
        try {
            const token = authHeader.replace("Bearer ", "");
            const decoded = jwt.verify(token, JWT_SECRET);
            store_id = decoded.store_id;
        } catch (error) {
            return {
                statusCode: 401,
                headers,
                body: JSON.stringify({ error: "Invalid token" }),
            };
        }

        if (action === "get_bookings") {
            const [rows] = await connection.execute(
                `SELECT
          id,
          booking_type AS bookingType,
          name,
          phone,
          event_date AS date,
          event_type AS eventType,
          package_name AS package,
          custom_order AS customOrder,
          notes,
          status
         FROM bookings
         WHERE store_id = ?
         ORDER BY created_at DESC`,
                [store_id]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ bookings: rows }),
            };
        }

        if (action === "update_status") {
            const { booking_id, status } = body;

            if (!booking_id || !status) {
                return {
                    statusCode: 400,
                    headers,
                    body: JSON.stringify({ error: "Missing booking_id or status" }),
                };
            }

            await connection.execute(
                "UPDATE bookings SET status = ? WHERE id = ? AND store_id = ?",
                [status, booking_id, store_id]
            );

            return {
                statusCode: 200,
                headers,
                body: JSON.stringify({ success: true }),
            };
        }

        return {
            statusCode: 400,
            headers,
            body: JSON.stringify({ error: "Invalid action" }),
        };
    } catch (err) {
        return {
            statusCode: 500,
            headers,
            body: JSON.stringify({ error: err.message }),
        };
    } finally {
        await connection.end();
    }
};